#!/bin/sh
/Users/Asone/.rvm/wrappers/streamcaster/ruby ~/routines/SoundCloud_StreamCaster/sc_downloader.rb


