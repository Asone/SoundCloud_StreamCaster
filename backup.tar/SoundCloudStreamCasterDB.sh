#!/bin/sh
/Users/Asone/.rvm/wrappers/streamcaster/ruby ~/routines/SoundCloud_StreamCaster/db_routine.rb

